package dev.vextra.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.vextra.module.HudModule;
import dev.vextra.module.Modules;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** Persistent config: atomic writes, corrupt files backed up, profiles, import/export. */
public final class VextraConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Gson COMPACT = new Gson();
    private static final Path DIR = FabricLoader.getInstance().getConfigDir().resolve("vextra");
    private static final Path FILE = DIR.resolve("config.json");
    private static VextraConfig instance = new VextraConfig();

    public Map<String, ModuleSettings> modules = new LinkedHashMap<>();
    public CrosshairSettings crosshair = new CrosshairSettings();
    public General general = new General();

    public static final class ModuleSettings {
        public boolean enabled = true;
        public int x = 4, y = 4;
        public float scale = 1.0f;
        public int textColor = 0xFFFFFF;
        public int bgColor = 0x000000;
        public float bgOpacity = 0.4f;
        public int padding = 3;
        public int borderColor = 0xFFFFFF;
        public int borderWidth = 0;
        public boolean rounded = true;
        public boolean shadow = true;
        // module specific
        public boolean horizontal = false;
        public int lowPercent = 20;
        public boolean sortByDuration = true;
        public boolean showNames = true;
        public boolean hearts = true;
        public boolean showPercent = true;
    }

    public static final class CrosshairSettings {
        public boolean enabled = false;
        public int size = 5, thickness = 1, gap = 3;
        public float opacity = 1f;
        public int color = 0xFFFFFF, outlineColor = 0x000000;
        public boolean outline = true, dot = false, dynamic = true;
        public int dynamicAmount = 4;

        public void preset(String name) {
            switch (name) {
                case "Classic" -> { size = 5; thickness = 1; gap = 3; dot = false; outline = true; }
                case "Dot" -> { size = 0; thickness = 3; gap = 0; dot = true; outline = true; }
                case "Wide" -> { size = 8; thickness = 2; gap = 5; dot = false; outline = true; }
            }
        }
    }

    public static final class General {
        public boolean autoSprint = false;
        public boolean quickTotemSwap = false; // off by default: respects server rules
    }

    public static VextraConfig get() { return instance; }

    public ModuleSettings of(String id, int defX, int defY) {
        return modules.computeIfAbsent(id, k -> {
            ModuleSettings s = new ModuleSettings();
            s.x = defX; s.y = defY;
            return s;
        });
    }

    public static void load() {
        try {
            Files.createDirectories(DIR);
            if (Files.exists(FILE)) {
                VextraConfig loaded = GSON.fromJson(Files.readString(FILE), VextraConfig.class);
                if (loaded != null) instance = fix(loaded);
            }
        } catch (Exception e) {
            try { if (Files.exists(FILE)) Files.move(FILE, DIR.resolve("config.broken.json"), StandardCopyOption.REPLACE_EXISTING); }
            catch (IOException ignored) {}
            instance = new VextraConfig();
        }
    }

    private static VextraConfig fix(VextraConfig c) {
        if (c.modules == null) c.modules = new LinkedHashMap<>();
        if (c.crosshair == null) c.crosshair = new CrosshairSettings();
        if (c.general == null) c.general = new General();
        return c;
    }

    public static void save() {
        try {
            Files.createDirectories(DIR);
            Path tmp = DIR.resolve("config.json.tmp");
            Files.writeString(tmp, GSON.toJson(instance));
            Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (Exception ignored) {}
    }

    public static void resetAll() { instance = new VextraConfig(); save(); }

    // ---- profiles / import / export ----
    public static String exportString() { return COMPACT.toJson(instance); }

    public static boolean importString(String json) {
        try {
            VextraConfig c = COMPACT.fromJson(json, VextraConfig.class);
            if (c == null) return false;
            instance = fix(c); save();
            return true;
        } catch (Exception e) { return false; }
    }

    public static void saveProfile(int n) {
        try {
            Path d = DIR.resolve("profiles");
            Files.createDirectories(d);
            Files.writeString(d.resolve("slot" + n + ".json"), GSON.toJson(instance));
        } catch (Exception ignored) {}
    }

    public static boolean loadProfile(int n) {
        try {
            Path f = DIR.resolve("profiles").resolve("slot" + n + ".json");
            if (!Files.exists(f)) return false;
            return importString(Files.readString(f));
        } catch (Exception e) { return false; }
    }

    /** Built-in layout presets. */
    public static void applyPreset(String name) {
        Set<String> minimal = Set.of("fps", "cps", "armor");
        for (HudModule m : Modules.ALL) {
            m.settings().enabled = !name.equals("Minimal") || minimal.contains(m.id);
        }
        save();
    }
}
