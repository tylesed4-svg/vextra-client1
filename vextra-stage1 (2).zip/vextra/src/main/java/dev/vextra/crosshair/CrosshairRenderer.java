package dev.vextra.crosshair;

import dev.vextra.config.VextraConfig.CrosshairSettings;
import dev.vextra.feature.CombatStats;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public final class CrosshairRenderer {
    private static float smooth;

    /** Smoothed dynamic expansion from movement and attacks. */
    public static float expansion(Minecraft mc, CrosshairSettings c) {
        float target = 0;
        if (c.dynamic && mc.player != null) {
            target = Math.min(c.dynamicAmount, (float) mc.player.getDeltaMovement().horizontalDistance() * 20f);
            if (CombatStats.recentAttack()) target = Math.min(c.dynamicAmount + 2, target + 2);
        }
        smooth += (target - smooth) * 0.25f;
        return smooth;
    }

    public static void draw(GuiGraphics g, int cx, int cy, CrosshairSettings c, float expand) {
        int a = Math.round(Math.clamp(c.opacity, 0f, 1f) * 255f);
        int col = (a << 24) | (c.color & 0xFFFFFF), oc = (a << 24) | (c.outlineColor & 0xFFFFFF);
        int t = Math.max(1, c.thickness), half = t / 2, len = c.size, gap = c.gap + Math.round(expand);
        int[][] r = new int[5][];
        int n = 0;
        if (len > 0) {
            r[n++] = new int[]{cx - half, cy - gap - len, t, len};
            r[n++] = new int[]{cx - half, cy + gap, t, len};
            r[n++] = new int[]{cx - gap - len, cy - half, len, t};
            r[n++] = new int[]{cx + gap, cy - half, len, t};
        }
        if (c.dot) r[n++] = new int[]{cx - half, cy - half, t, t};
        if (c.outline) for (int i = 0; i < n; i++)
            g.fill(r[i][0] - 1, r[i][1] - 1, r[i][0] + r[i][2] + 1, r[i][1] + r[i][3] + 1, oc);
        for (int i = 0; i < n; i++)
            g.fill(r[i][0], r[i][1], r[i][0] + r[i][2], r[i][1] + r[i][3], col);
    }
    private CrosshairRenderer() {}
}
