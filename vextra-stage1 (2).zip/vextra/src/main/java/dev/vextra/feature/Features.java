package dev.vextra.feature;

import dev.vextra.config.VextraConfig;
import dev.vextra.screen.VextraScreen;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;

public final class Features {
    public static boolean sneakToggled;
    private static boolean sprintForced, sneakForced;
    private static long lastSwap;

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(Features::tick);
        AttackEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
            if (level.isClientSide()) CombatStats.onAttack(entity);
            return InteractionResult.PASS;
        });
    }

    private static void tick(Minecraft mc) {
        if (mc.player == null) return;
        while (Keys.MENU.consumeClick()) mc.setScreen(new VextraScreen(mc.screen));
        while (Keys.HIDE.consumeClick()) dev.vextra.hud.HudManager.hidden = !dev.vextra.hud.HudManager.hidden;
        CombatStats.tick(mc);
        VextraConfig.General gen = VextraConfig.get().general;

        // Auto sprint: holds the normal sprint key while moving forward (vanilla behaviour)
        if (gen.autoSprint) {
            if (mc.options.keyUp.isDown() && !mc.player.isShiftKeyDown()) mc.options.keySprint.setDown(true);
            sprintForced = true;
        } else if (sprintForced) {
            mc.options.keySprint.setDown(false);
            sprintForced = false;
        }

        // Toggle sneak (key is unbound by default; set it in Controls)
        while (Keys.SNEAK.consumeClick()) sneakToggled = !sneakToggled;
        if (sneakToggled) { mc.options.keyShift.setDown(true); sneakForced = true; }
        else if (sneakForced) { mc.options.keyShift.setDown(false); sneakForced = false; }

        // Quick totem: one normal inventory swap per key press, only if enabled in settings
        while (Keys.TOTEM.consumeClick()) if (gen.quickTotemSwap) quickTotem(mc);
    }

    private static void quickTotem(Minecraft mc) {
        if (mc.screen != null || mc.gameMode == null) return;
        if (mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) return;
        long now = System.currentTimeMillis();
        if (now - lastSwap < 300) return;
        var inv = mc.player.getInventory();
        for (int i = 0; i < 36; i++) {
            if (inv.getItem(i).is(Items.TOTEM_OF_UNDYING)) {
                int slot = i < 9 ? 36 + i : i;
                mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, slot, 40, ClickType.SWAP, mc.player);
                lastSwap = now;
                return;
            }
        }
    }
    private Features() {}
}
