package dev.vextra.module;

import dev.vextra.config.VextraConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

import java.util.List;

public final class ArmorHud extends HudModule {
    private static final EquipmentSlot[] SLOTS = {
        EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };

    public ArmorHud() { super("armor", "Armor HUD", 4, 150); }

    @Override public boolean custom() { return true; }

    private int cell(Minecraft mc) { return 16 + 2 + mc.font.width("100%") + 4; }

    @Override public int width(Minecraft mc, VextraConfig.ModuleSettings s) {
        return s.horizontal ? cell(mc) * 4 - 4 : cell(mc) - 4;
    }
    @Override public int height(Minecraft mc, VextraConfig.ModuleSettings s) {
        return s.horizontal ? 16 : 18 * 4 - 2;
    }

    @Override
    public void draw(GuiGraphics g, Minecraft mc, VextraConfig.ModuleSettings s) {
        if (mc.player == null) return;
        for (int i = 0; i < 4; i++) {
            ItemStack st = mc.player.getItemBySlot(SLOTS[i]);
            int x = s.horizontal ? i * cell(mc) : 0;
            int y = s.horizontal ? 0 : i * 18;
            if (st.isEmpty()) continue;
            g.renderItem(st, x, y);
            if (st.isDamageableItem()) {
                int max = st.getMaxDamage();
                int pct = Math.max(0, Math.round(100f * (max - st.getDamageValue()) / max));
                int color = pct <= s.lowPercent ? 0xFFFF5555 : pct <= 50 ? 0xFFFFAA00 : 0xFF55FF55;
                g.drawString(mc.font, pct + "%", x + 18, y + 4, color, s.shadow);
            }
        }
    }

    @Override public List<Opt> options() {
        return List.of(
            Opt.toggle("Horizontal", () -> settings().horizontal, v -> settings().horizontal = v),
            Opt.slider("Low warning %", () -> (float) settings().lowPercent, v -> settings().lowPercent = Math.round(v), 0, 100, true));
    }
}
