package dev.vextra.module;

import dev.vextra.config.VextraConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.List;

public abstract class HudModule {
    public final String id, displayName;
    public final int defX, defY;
    /** Last drawn bounds in GUI pixels (used for drag and drop). */
    public int bx, by, bw, bh;

    protected HudModule(String id, String displayName, int defX, int defY) {
        this.id = id; this.displayName = displayName; this.defX = defX; this.defY = defY;
    }

    public VextraConfig.ModuleSettings settings() { return VextraConfig.get().of(id, defX, defY); }

    public String text(Minecraft mc) { return null; }
    public String[] lines(Minecraft mc) { return null; }
    public void frame(Minecraft mc) {}
    public List<Opt> options() { return List.of(); }

    public boolean custom() { return false; }
    public int width(Minecraft mc, VextraConfig.ModuleSettings s) { return 0; }
    public int height(Minecraft mc, VextraConfig.ModuleSettings s) { return 0; }
    /** Drawn at (0,0) inside the box, already translated/scaled. */
    public void draw(GuiGraphics g, Minecraft mc, VextraConfig.ModuleSettings s) {}
}
