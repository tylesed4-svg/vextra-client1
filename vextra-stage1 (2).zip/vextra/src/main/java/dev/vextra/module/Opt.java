package dev.vextra.module;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** A module-specific option shown automatically in the settings menu. */
public final class Opt {
    public final String label;
    public final boolean toggle, integer;
    public final BooleanSupplier getB; public final Consumer<Boolean> setB;
    public final Supplier<Float> getF; public final Consumer<Float> setF;
    public final float min, max;

    private Opt(String l, boolean t, boolean i, BooleanSupplier gb, Consumer<Boolean> sb,
                Supplier<Float> gf, Consumer<Float> sf, float min, float max) {
        label = l; toggle = t; integer = i; getB = gb; setB = sb; getF = gf; setF = sf; this.min = min; this.max = max;
    }
    public static Opt toggle(String l, BooleanSupplier g, Consumer<Boolean> s) {
        return new Opt(l, true, false, g, s, null, null, 0, 0);
    }
    public static Opt slider(String l, Supplier<Float> g, Consumer<Float> s, float min, float max, boolean integer) {
        return new Opt(l, false, integer, null, null, g, s, min, max);
    }
}
