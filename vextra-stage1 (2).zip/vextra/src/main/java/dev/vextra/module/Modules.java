package dev.vextra.module;

import dev.vextra.config.VextraConfig;
import dev.vextra.feature.CombatStats;
import dev.vextra.feature.Features;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Items;

import java.util.List;

public final class Modules {
    public static final List<HudModule> ALL = List.of(
        new HudModule("fps", "FPS", 4, 4) {
            @Override public String text(Minecraft mc) { return mc.getFps() + " FPS"; }
        },
        new HudModule("cps", "CPS", 4, 24) {
            private boolean lDown, rDown;
            private final long[] l = new long[64], r = new long[64];
            private int li, ri, lc, rc;
            private long lastCount;

            @Override public void frame(Minecraft mc) {
                long now = System.currentTimeMillis();
                boolean ld = mc.mouseHandler.isLeftPressed(), rd = mc.mouseHandler.isRightPressed();
                if (ld && !lDown) l[li++ & 63] = now;
                if (rd && !rDown) r[ri++ & 63] = now;
                lDown = ld; rDown = rd;
                if (now - lastCount >= 100) { lastCount = now; lc = count(l, now); rc = count(r, now); }
            }
            private static int count(long[] a, long now) {
                int n = 0;
                for (long t : a) if (t != 0 && now - t <= 1000) n++;
                return n;
            }
            @Override public String text(Minecraft mc) { return lc + " | " + rc + " CPS"; }
        },
        new HudModule("ping", "Ping", 4, 44) {
            @Override public String text(Minecraft mc) {
                if (mc.player == null || mc.getConnection() == null) return null;
                var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                return info == null ? "Ping: -" : "Ping: " + info.getLatency() + " ms";
            }
        },
        new HudModule("coords", "Coordinates", 4, 64) {
            @Override public String text(Minecraft mc) {
                if (mc.player == null) return null;
                return String.format("XYZ %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
            }
        },
        new HudModule("sprint", "Sprint Status", 4, 84) {
            @Override public String text(Minecraft mc) {
                if (mc.player == null) return null;
                if (Features.sneakToggled) return "Sneaking (toggled)";
                return mc.player.isSprinting() ? "Sprinting" : "Walking";
            }
        },
        new HudModule("combo", "Combo / Hits", 4, 104) {
            @Override public String[] lines(Minecraft mc) {
                return new String[]{"Combo: " + CombatStats.combo, "Hits: " + CombatStats.hits + "  Taken: " + CombatStats.taken};
            }
        },
        new HudModule("health", "Health", 4, 128) {
            @Override public String text(Minecraft mc) {
                if (mc.player == null) return null;
                VextraConfig.ModuleSettings s = settings();
                float hp = mc.player.getHealth(), max = mc.player.getMaxHealth(), abs = mc.player.getAbsorptionAmount();
                int pct = Math.round(100f * hp / max);
                StringBuilder sb = new StringBuilder();
                if (s.hearts) {
                    int full = (int) Math.ceil(hp / 2f), total = (int) Math.ceil(max / 2f);
                    sb.append("§c").append("♥".repeat(Math.max(0, full)));
                    sb.append("§8").append("♥".repeat(Math.max(0, total - full)));
                    if (abs > 0) sb.append("§6").append("♥".repeat((int) Math.ceil(abs / 2f)));
                    if (s.showPercent) sb.append(" §f").append(pct).append("%");
                } else {
                    sb.append(String.format("HP %.1f/%.0f", hp, max));
                    if (s.showPercent) sb.append(" (").append(pct).append("%)");
                    if (abs > 0) sb.append(String.format(" +%.0f", abs));
                }
                return sb.toString();
            }
            @Override public List<Opt> options() {
                return List.of(
                    Opt.toggle("Heart icons", () -> settings().hearts, v -> settings().hearts = v),
                    Opt.toggle("Show percent", () -> settings().showPercent, v -> settings().showPercent = v));
            }
        },
        new ArmorHud(),
        new PotionHud(),
        new HudModule("target", "Target Info", 180, 24) {
            @Override public String[] lines(Minecraft mc) {
                Entity e = mc.crosshairPickEntity;
                LivingEntity le = e instanceof LivingEntity l ? l : CombatStats.lastTarget;
                if (le == null) return null;
                return new String[]{le.getName().getString(),
                    String.format("§c♥ §f%.1f / %.0f", le.getHealth(), le.getMaxHealth())};
            }
        },
        new HudModule("totem", "Totem Warning", 180, 60) {
            @Override public String text(Minecraft mc) {
                if (mc.player == null || mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) return null;
                var inv = mc.player.getInventory();
                int n = 0;
                for (int i = 0; i < 36; i++) if (inv.getItem(i).is(Items.TOTEM_OF_UNDYING)) n++;
                return n > 0 ? "§eTotem not in offhand (" + n + ")" : "§c§lNO TOTEM!";
            }
        },
        new HudModule("keys", "Keystrokes", 300, 120) {
            @Override public boolean custom() { return true; }
            @Override public int width(Minecraft mc, VextraConfig.ModuleSettings s) { return 52; }
            @Override public int height(Minecraft mc, VextraConfig.ModuleSettings s) { return 64; }
            @Override public void draw(GuiGraphics g, Minecraft mc, VextraConfig.ModuleSettings s) {
                var o = mc.options;
                key(g, mc, s, "W", 18, 0, 16, 16, o.keyUp.isDown());
                key(g, mc, s, "A", 0, 18, 16, 16, o.keyLeft.isDown());
                key(g, mc, s, "S", 18, 18, 16, 16, o.keyDown.isDown());
                key(g, mc, s, "D", 36, 18, 16, 16, o.keyRight.isDown());
                key(g, mc, s, "SPACE", 0, 36, 52, 10, o.keyJump.isDown());
                key(g, mc, s, "LMB", 0, 48, 25, 16, o.keyAttack.isDown());
                key(g, mc, s, "RMB", 27, 48, 25, 16, o.keyUse.isDown());
            }
            private void key(GuiGraphics g, Minecraft mc, VextraConfig.ModuleSettings s,
                             String label, int x, int y, int w, int h, boolean down) {
                g.fill(x, y, x + w, y + h, down ? 0xAAFFFFFF : 0x33FFFFFF);
                int tc = down ? 0xFF000000 : (0xFF000000 | s.textColor);
                g.drawString(mc.font, label, x + (w - mc.font.width(label)) / 2, y + (h - 8) / 2 + 1, tc, false);
            }
        }
    );
    private Modules() {}
}
